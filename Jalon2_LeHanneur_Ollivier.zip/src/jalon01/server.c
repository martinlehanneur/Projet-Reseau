#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/ipc.h>
#include<fcntl.h>
#include <errno.h>
#include <assert.h>
#include <poll.h>


void error(const char *msg)
{
  perror(msg);
  exit(1);
}

int do_socket(int domaine, int type, int protocol){
  int yes=1;

  int sockfd= socket(domaine, type, protocol);

  if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1)
  error("ERROR setting socket options");

  return sockfd;
}

void do_bind(int sockfd,struct sockaddr_in sin){
  if (bind(sockfd,(struct sockaddr*)&sin,sizeof(sin))<0 ){
    error("Server : bind");
    exit (1);
  }
}

void do_listen(int sockfd, int nb_connexions){
  if (listen(sockfd,nb_connexions)<0){
    error("Server : listen");
    exit (1);
  }
}

int do_accept(int sockfd){
  int var = accept(sockfd,NULL,NULL);
  if(var<0){
    error("server: accept");
  }
  return var;
}

void do_read(int connexion, char *buf, int len){
//  int len=sizeof(buf);
  if(read(connexion,buf,len)<0){
    error("server: read");
  }
}

void do_write(int connexion, char *buf, int len){
//  int len=sizeof(buf);
  if(write(connexion,buf,len)<0){
    error("server: write");
  }
}

int main(int argc, char** argv)
{
  if (argc != 2)
  {
    fprintf(stderr, "usage: RE216_SERVER port\n");
    return 1;
  }
  int nb_connexions=3;

  struct sockaddr_in sin;
  struct pollfd fds[nb_connexions+1];
  sin.sin_family=AF_INET;
  sin.sin_port=htons(atoi(argv[1]));
  sin.sin_addr.s_addr=htonl (INADDR_ANY);
  int sockfd = do_socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);


  fds[0].fd=sockfd;
  fds[0].events=POLLIN;
  for(int j=1; j<=nb_connexions; j++){
    fds[j].fd=0;
  }

  int len=100;
  char buf[len];
  struct sockaddr_in sinclient;
  socklen_t* addrlen= (socklen_t*)sizeof(sinclient);

  do_bind(sockfd, sin);
  do_listen(sockfd, nb_connexions+1);
  while(1){
    poll(fds, nb_connexions,0);
    for(int i=0; i<=nb_connexions; i++){
      if(fds[i].revents==POLLIN){
        if(fds[i].fd==sockfd){
          int connexion=do_accept(sockfd);
          for(int k=0; k<nb_connexions; k++){
            if (fds[k].fd==0){
              fds[k].fd=connexion;
              fds[k].events=POLLIN;
              do_write(fds[k].fd,"Vous êtes maintenant connecté",len);
              break;
            }
            else if (k==(nb_connexions-1) && fds[k].fd!=0){
              fds[nb_connexions].fd=connexion;
              fds[nb_connexions].events=POLLIN;
              do_write(fds[nb_connexions].fd,"0",len);
              close(fds[nb_connexions].fd);
            }
          }
        }
        else {
          do_read(fds[i].fd, buf, len);
          if(buf[0]=='/'&& buf[1]=='q' && buf[2]=='u' && buf[3]=='i' && buf[4]=='t'){
            do_write(fds[i].fd,"Vous allez être déconnecté",len);
            close(fds[i].fd);
            fds[i].fd=0;
          }
          else{
          do_write(fds[i].fd,buf,len);
        }
        }
      }
    }

}
  //close (sockfd);
  exit (0);
}
